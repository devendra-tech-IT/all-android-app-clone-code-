package com.example.swiggy

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import coil.compose.AsyncImage
import com.google.android.gms.ads.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// --- DATA MODELS ---
data class FoodItem(val id: Int, val name: String, val price: Double, val rating: String, val imageUrl: String, val category: String)
data class User(val name: String, val email: String, val password: String)

// --- VIEWMODEL ---
class FoodViewModel : ViewModel() {
    private val _foodItems = MutableStateFlow(listOf(
        FoodItem(1, "Hyderabadi Biryani", 250.0, "4.8", "https://images.unsplash.com/photo-1563379091339-03b21bc4a4f8?q=80&w=400", "Biryani"),
        FoodItem(2, "Cakes & Desserts", 180.0, "4.5", "https://images.unsplash.com/photo-1565557623262-b51c2513a641?q=80&w=400", "Cakes"),
        FoodItem(3, "Cheese Burst Pizza", 350.0, "4.7", "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=400", "Pizza"),
        FoodItem(4, "Crispy Chicken Burger", 120.0, "4.3", "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=400", "Burgers"),
        FoodItem(5, "Hakka Noodles", 150.0, "4.2", "https://images.unsplash.com/photo-1585032226651-759b368d7246?q=80&w=400", "Chinese")
    ))
    val foodItems = _foodItems.asStateFlow()
    val cart = mutableStateListOf<FoodItem>()
    val orderHistory = mutableStateListOf<List<FoodItem>>()
    val registeredUsers = mutableStateListOf<User>()

    // Set true by default to show Home first
    var isLoggedIn by mutableStateOf(true)
    var isDarkMode by mutableStateOf(false)
    var userName by mutableStateOf("Guest User")
    var userEmail by mutableStateOf("guest@swiggy.com")
    var userAddress by mutableStateOf("")
    var selectedPaymentMethod by mutableStateOf("UPI")

    fun addToCart(item: FoodItem) { cart.add(item) }
    fun clearCart() { cart.clear() }
    fun completeOrder() {
        if (cart.isNotEmpty()) {
            orderHistory.add(cart.toList())
            cart.clear()
        }
    }

    fun registerUser(user: User) { registeredUsers.add(user) }
    fun loginUser(email: String, pass: String): Boolean {
        val user = registeredUsers.find { it.email == email && it.password == pass }
        return if (user != null) {
            this.userName = user.name
            this.userEmail = user.email
            this.isLoggedIn = true
            true
        } else false
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        setContent {
            val viewModel: FoodViewModel = viewModel()
            val colorScheme = if (viewModel.isDarkMode) darkColorScheme(primary = Color(0xFFFF5722))
            else lightColorScheme(primary = Color(0xFFFF5722))

            MaterialTheme(colorScheme = colorScheme) {
                AppNavigation(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation(viewModel: FoodViewModel) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(Modifier.height(12.dp))
                Text("ZipMeal Menu", Modifier.padding(16.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                NavigationDrawerItem(
                    label = { Text("Home") },
                    selected = false,
                    onClick = { navController.navigate("home"); scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.Home, null) }
                )
                NavigationDrawerItem(
                    label = { Text("Profile Settings") },
                    selected = false,
                    onClick = { navController.navigate("profile"); scope.launch { drawerState.close() } },
                    icon = { Icon(Icons.Default.Person, null) }
                )
                Divider(Modifier.padding(vertical = 8.dp))
                NavigationDrawerItem(
                    label = { Text("Logout") },
                    selected = false,
                    onClick = {
                        viewModel.isLoggedIn = false
                        navController.navigate("login") { popUpTo(0) }
                        scope.launch { drawerState.close() }
                    },
                    icon = { Icon(Icons.Default.Logout, null) }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("ZipMeal", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, "Menu")
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.isDarkMode = !viewModel.isDarkMode }) {
                            Icon(if (viewModel.isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode, null)
                        }
                    }
                )
            },
            bottomBar = {
                if (viewModel.isLoggedIn) {
                    NavigationBar {
                        val navBackStackEntry by navController.currentBackStackEntryAsState()
                        val currentRoute = navBackStackEntry?.destination?.route
                        val items = listOf("home" to Icons.Default.Home, "search" to Icons.Default.Search, "cart" to Icons.Default.ShoppingCart, "profile" to Icons.Default.Person)

                        items.forEach { (route, icon) ->
                            NavigationBarItem(
                                selected = currentRoute == route,
                                onClick = { navController.navigate(route) },
                                icon = {
                                    if (route == "cart") {
                                        BadgedBox(badge = { if(viewModel.cart.isNotEmpty()) Badge { Text(viewModel.cart.size.toString()) } }) { Icon(icon, null) }
                                    } else Icon(icon, null)
                                },
                                label = { Text(route.replaceFirstChar { it.uppercase() }) }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(navController, startDestination = "login", modifier = Modifier.padding(padding)) {
                composable("login") { LoginScreen(viewModel, navController) }
                composable("registration") { RegistrationScreen(viewModel, navController) }
                composable("home") { HomeScreen(viewModel, navController) }
                composable("search") { SearchScreen(viewModel, navController) }
                composable("cart") { CartScreen(viewModel, navController) }
                composable("profile") { ProfileScreen(viewModel, navController) }
                composable("checkout") { CheckoutScreen(viewModel, navController) }
            }
        }
    }
}

@Composable
fun LoginScreen(vm: FoodViewModel, navController: NavHostController) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        AsyncImage("https://upload.wikimedia.org/wikipedia/en/thumb/1/12/Swiggy_logo.svg/1200px-Swiggy_logo.svg.png", null, Modifier.size(100.dp))
        Text("ZipMeal Login", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFF5722))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = { IconButton({ visible = !visible }) { Icon(if (visible) Icons.Default.Visibility else Icons.Default.VisibilityOff, null) } }
        )
        Button({ if (vm.loginUser(email, pass)) navController.navigate("home") { popUpTo("login") { inclusive = true } } else Toast.makeText(ctx, "Invalid Credentials", Toast.LENGTH_SHORT).show() }, Modifier.fillMaxWidth().padding(top = 16.dp)) { Text("Login") }
        TextButton({ navController.navigate("registration") }) { Text("New User? Register") }
    }
}

@Composable
fun RegistrationScreen(vm: FoodViewModel, navController: NavHostController) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Register", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(name, { name = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth(), visualTransformation = PasswordVisualTransformation())
        Button({ if(name.isNotBlank()){ vm.registerUser(User(name, email, pass)); navController.navigate("login") } }, Modifier.fillMaxWidth().padding(top = 16.dp)) { Text("Register") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: FoodViewModel, navController: NavHostController) {
    val allFoods by vm.foodItems.collectAsState()
    var selectedCat by remember { mutableStateOf("All") }
    val filteredFoods = if (selectedCat == "All") allFoods else allFoods.filter { it.category == selectedCat }

    Column(Modifier.fillMaxSize()) {
        Text("What's on your mind?", Modifier.padding(16.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        LazyRow(Modifier.padding(horizontal = 8.dp)) {
            items(listOf("All", "Biryani", "Pizza", "Burgers", "Chinese")) { cat ->
                FilterChip(selected = selectedCat == cat, onClick = { selectedCat = cat }, label = { Text(cat) }, modifier = Modifier.padding(4.dp))
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(filteredFoods) { food ->
                Card(Modifier.padding(8.dp).fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Column {
                        AsyncImage(food.imageUrl, null, Modifier.fillMaxWidth().height(160.dp), contentScale = ContentScale.Crop)
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text(food.name, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                                Text("₹${food.price}", color = Color(0xFFFF5722), fontWeight = FontWeight.Bold)
                            }
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { vm.addToCart(food) }, Modifier.weight(1f)) { Text("Add to Cart") }
                                OutlinedButton(onClick = { vm.clearCart(); vm.addToCart(food); navController.navigate("checkout") }, Modifier.weight(1f)) { Text("Buy Now") }
                            }
                        }
                    }
                }
            }
        }
        BannerAdView()
    }
}

@Composable
fun CartScreen(vm: FoodViewModel, navController: NavHostController) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Your Cart", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (vm.cart.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Cart is empty") }
        else {
            LazyColumn(Modifier.weight(1f)) {
                items(vm.cart) { item ->
                    ListItem(headlineContent = { Text(item.name) }, trailingContent = { Text("₹${item.price}") })
                }
            }
            Button(onClick = { navController.navigate("checkout") }, Modifier.fillMaxWidth()) {
                Text("Proceed to Checkout (₹${vm.cart.sumOf { it.price }})")
            }
        }
    }
}

@Composable
fun CheckoutScreen(vm: FoodViewModel, navController: NavHostController) {
    var success by remember { mutableStateOf(false) }
    if (success) {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            Icon(Icons.Default.CheckCircle, null, Modifier.size(100.dp), tint = Color(0xFF4CAF50))
            Text("Order Placed!", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Button({ vm.completeOrder(); success = false; navController.navigate("home") { popUpTo(0) } }) { Text("Done") }
        }
    } else {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            OutlinedTextField(vm.userAddress, { vm.userAddress = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            listOf("UPI", "Cash on Delivery").forEach { opt ->
                Row(Modifier.fillMaxWidth().clickable { vm.selectedPaymentMethod = opt }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(vm.selectedPaymentMethod == opt, null)
                    Text(opt, Modifier.padding(start = 8.dp))
                }
            }
            Spacer(Modifier.weight(1f))
            Button({ if(vm.userAddress.isNotBlank()) success = true }, Modifier.fillMaxWidth()) { Text("Confirm Order") }
        }
    }
}

@Composable
fun ProfileScreen(vm: FoodViewModel, navController: NavHostController) {
    var isEditing by remember { mutableStateOf(false) }
    var tempName by remember { mutableStateOf(vm.userName) }
    var tempAddr by remember { mutableStateOf(vm.userAddress) }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item {
            Box(Modifier.size(100.dp).clip(CircleShape).background(Color.LightGray), Alignment.Center) { Icon(Icons.Default.Person, null, Modifier.size(60.dp)) }
            Spacer(Modifier.height(16.dp))
            if (isEditing) {
                OutlinedTextField(tempName, { tempName = it }, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(tempAddr, { tempAddr = it }, label = { Text("Address") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                Button(onClick = { vm.userName = tempName; vm.userAddress = tempAddr; isEditing = false }, Modifier.padding(top = 16.dp)) { Text("Save") }
            } else {
                Text(vm.userName, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text(vm.userAddress, color = Color.Gray)
                TextButton(onClick = { isEditing = true }) { Text("Edit Profile & Address") }
            }
            Divider(Modifier.padding(vertical = 24.dp))
            Text("Order History", fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
        }
        items(vm.orderHistory.reversed()) { order ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Total: ₹${order.sumOf { it.price }}", fontWeight = FontWeight.Bold)
                    order.forEach { Text("- ${it.name}", fontSize = 12.sp) }
                }
            }
        }
        item {
            Button(onClick = { vm.isLoggedIn = false; navController.navigate("login") { popUpTo(0) } }, Modifier.fillMaxWidth().padding(top = 32.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.Red)) {
                Text("Logout")
            }
        }
    }
}

@Composable
fun SearchScreen(vm: FoodViewModel, navController: NavHostController) {
    val all by vm.foodItems.collectAsState()
    var q by remember { mutableStateOf("") }
    val filtered = all.filter { it.name.contains(q, true) }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp), leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text("Search food...") })
        LazyColumn(Modifier.weight(1f)) {
            items(filtered) { food ->
                ListItem(headlineContent = { Text(food.name) }, trailingContent = { IconButton({ vm.addToCart(food) }) { Icon(Icons.Default.Add, null) } })
            }
        }
    }
}

@Composable
fun BannerAdView() {
    AndroidView(modifier = Modifier.fillMaxWidth().height(50.dp), factory = { ctx ->
        AdView(ctx).apply {
            setAdSize(AdSize.BANNER)
            adUnitId = "ca-app-pub-3940256099942544/6300978111"
            loadAd(AdRequest.Builder().build())
        }
    })
}