class Book(bookId: String, bookTitle: String, bookAuthor: String, totalQty: Int) {
    var id: String = bookId
    var title: String = bookTitle
    var author: String = bookAuthor
    var quantity: Int = totalQty
    var available: Int = totalQty
}

class LibraryMember(memId: String, memName: String) {
    var memberId: String = memId
    var name: String = memName
    var borrowedCount: Int = 0
}

class LoanRecord(bId: String, mId: String, day: Int) {
    var bookId: String = bId
    var memberId: String = mId
    var dayBorrowed: Int = day
    var isReturned: Boolean = false
}

class LibraryManagement {
    var books = arrayOfNulls<Book>(10)
    var members = arrayOfNulls<LibraryMember>(10)
    var loans = arrayOfNulls<LoanRecord>(20)
    var currentDay: Int = 1

    fun advanceDay() {
        currentDay++
        println("\n>>> A day has passed. It is now Day " + currentDay + " <<<")
    }

    fun addBook(id: String, title: String, author: String, quantity: Int) {
        for (i in 0 until 10) {
            if (books[i] == null) {
                books[i] = Book(id, title, author, quantity)
                println("Library: Added " + quantity + " copies of '" + title + "'")
                return
            }
        }
        println("Library: Shelf is full! Cannot add more distinct books.")
    }

    fun registerMember(id: String, name: String) {
        for (i in 0 until 10) {
            if (members[i] == null) {
                members[i] = LibraryMember(id, name)
                println("Library: Registered member '" + name + "'")
                return
            }
        }
        println("Library: Member list is full.")
    }

    fun displayBooks() {
        println("\n--- Available Books ---")
        var count = 0
        for (i in 0 until 10) {
            var b = books[i]
            if (b != null) {
                println("ID: " + b.id + " | Title: " + b.title + " | Author: " + b.author + " | Available: " + b.available + "/" + b.quantity)
                count++
            }
        }
        if (count == 0) println("No books in the library.")
    }

    fun displayMembers() {
        println("\n--- Registered Members ---")
        var count = 0
        for (i in 0 until 10) {
            var m = members[i]
            if (m != null) {
                println("ID: " + m.memberId + " | Name: " + m.name + " | Books Held: " + m.borrowedCount)
                count++
            }
        }
        if (count == 0) println("No members registered.")
    }

    fun deleteBook(bookId: String) {
        for (i in 0 until 10) {
            var b = books[i]
            if (b != null && b.id == bookId) {
                if (b.available < b.quantity) {
                    println("Error: Cannot delete book! Some copies are currently borrowed.")
                    return
                }
                books[i] = null
                println("Library: Book deleted.")
                return
            }
        }
        println("Library: Book ID not found.")
    }

    fun deleteMember(memberId: String) {
        for (i in 0 until 10) {
            var m = members[i]
            if (m != null && m.memberId == memberId) {
                if (m.borrowedCount > 0) {
                    println("Error: Cannot delete member! They still have " + m.borrowedCount + " book(s) to return.")
                    return
                }
                members[i] = null
                println("Library: Member deleted.")
                return
            }
        }
        println("Library: Member ID not found.")
    }

    fun borrowBook(bookId: String, memberId: String) {
        var foundBook: Book? = null
        var foundMember: LibraryMember? = null

        for (i in 0 until 10) {
            if (books[i] != null && books[i]?.id == bookId) foundBook = books[i]
            if (members[i] != null && members[i]?.memberId == memberId) foundMember = members[i]
        }

        if (foundBook != null && foundMember != null) {
            if (foundBook.available > 0) {
                for (i in 0 until 20) {
                    if (loans[i] == null) {
                        loans[i] = LoanRecord(bookId, memberId, currentDay)
                        foundBook.available--
                        foundMember.borrowedCount++
                        println("Library: '" + foundBook.title + "' borrowed by " + foundMember.name + " on Day " + currentDay + ". Return within 7 days.")
                        return
                    }
                }
                println("Library: Loan system is full, cannot process more transactions.")
            } else {
                println("Library: All copies of this book are currently borrowed.")
            }
        } else {
            println("Library: Invalid Book ID or Member ID.")
        }
    }

    fun returnBook(bookId: String, memberId: String) {
        var foundLoan: LoanRecord? = null
        
        for (i in 0 until 20) {
            var l = loans[i]
            if (l != null && l.bookId == bookId && l.memberId == memberId && !l.isReturned) {
                foundLoan = l
                l.isReturned = true
                break
            }
        }

        if (foundLoan != null) {
            var daysKept = currentDay - foundLoan.dayBorrowed
            if (daysKept > 7) {
                var fine = (daysKept - 7) * 10
                println("Warning: Book is late! Late fine is Rs. " + fine)
            } else {
                var daysRemaining = 7 - daysKept
                println("Book returned on time. You had " + daysRemaining + " days remaining.")
            }

            for (i in 0 until 10) {
                if (books[i] != null && books[i]?.id == bookId) books[i]?.available = (books[i]?.available ?: 0) + 1
                if (members[i] != null && members[i]?.memberId == memberId) members[i]?.borrowedCount = (members[i]?.borrowedCount ?: 1) - 1
            }
            println("Library: Book successfully returned on Day " + currentDay + ".")
        } else {
            println("Library: No active loan found for this Book ID and Member ID.")
        }
    }
}

fun main() {
    var library = LibraryManagement()
    var running = true

    println("=== Advanced Library Management System ===")

    while (running) {
        println("\n--- Menu (Today is Day " + library.currentDay + ") ---")
        println("1. Display Books")
        println("2. Display Members")
        println("3. Add Book")
        println("4. Add Member")
        println("5. Delete Book")
        println("6. Delete Member")
        println("7. Borrow Book")
        println("8. Return Book")
        println("9. Advance to Next Day")
        println("10. Exit")
        print("Enter choice: ")
        
        var choice = readln()

        if (choice == "1") library.displayBooks()
        else if (choice == "2") library.displayMembers()
        
        else if (choice == "3") {
            print("Enter new Book ID (e.g., B1): ")
            var id = readln()
            print("Enter Title: ")
            var title = readln()
            print("Enter Author: ")
            var author = readln()
            print("Enter Quantity to add: ")
            var qty = readln().toInt()
            library.addBook(id, title, author, qty)
        }
        
        else if (choice == "4") {
            print("Enter new Member ID (e.g., M1): ")
            var id = readln()
            print("Enter Name: ")
            var name = readln()
            library.registerMember(id, name)
        }
        
        else if (choice == "5") {
            library.displayBooks()
            print("Enter ID of Book to Delete: ")
            var id = readln()
            library.deleteBook(id)
        }
        
        else if (choice == "6") {
            library.displayMembers()
            print("Enter ID of Member to Delete: ")
            var id = readln()
            library.deleteMember(id)
        }
        
        else if (choice == "7") {
            library.displayBooks()
            library.displayMembers()
            print("Enter Book ID to Borrow: ")
            var bookId = readln()
            print("Enter Member ID: ")
            var memberId = readln()
            library.borrowBook(bookId, memberId)
        }
        
        else if (choice == "8") {
            library.displayBooks()
            library.displayMembers()
            print("Enter Book ID to Return: ")
            var bookId = readln()
            print("Enter Member ID returning the book: ")
            var memberId = readln()
            library.returnBook(bookId, memberId)
        }
        
        else if (choice == "9") {
            library.advanceDay()
        }
        
        else if (choice == "10") {
            running = false
            println("Goodbye!")
        } else {
            println("Invalid choice.")
        }
    }
}